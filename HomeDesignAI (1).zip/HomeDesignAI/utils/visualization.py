import plotly.graph_objects as go
import numpy as np

def create_floor_plan(layout_data):
    """Create a 2D visualization of the floor plan"""

    # Create figure
    fig = go.Figure()

    # Color mapping for different room types
    color_map = {
        'bedroom': '#B3E5FC',  # Light Blue
        'bathroom': '#F5F5F5',  # Light Grey
        'kitchen': '#FFECB3',  # Light Yellow
        'living_room': '#C8E6C9',  # Light Green
        'dining_room': '#FFE0B2',  # Light Orange
        'office': '#E1BEE7'  # Light Purple
    }

    # Add rooms as rectangles
    for _, room in layout_data.iterrows():
        # Create rectangle
        fig.add_shape(
            type="rect",
            x0=room['x'],
            y0=room['y'],
            x1=room['x'] + room['width'],
            y1=room['y'] + room['height'],
            line=dict(
                color="Black",
                width=2
            ),
            fillcolor=color_map.get(room['room_type'], '#FFFFFF'),
            layer='below'
        )

        # Add room labels
        fig.add_annotation(
            x=room['x'] + room['width']/2,
            y=room['y'] + room['height']/2,
            text=f"{room['room_type']}<br>({int(room['size'])} sq ft)",
            showarrow=False,
            font=dict(
                size=12,
                color='black'
            ),
            bgcolor='rgba(255, 255, 255, 0.8)'
        )

    # Calculate total dimensions for proper scaling
    max_x = layout_data['x'].max() + layout_data['width'].max()
    max_y = layout_data['y'].max() + layout_data['height'].max()

    # Update layout
    fig.update_layout(
        showlegend=False,
        plot_bgcolor='white',
        width=800,
        height=600,
        margin=dict(l=20, r=20, t=20, b=20),
        xaxis=dict(
            range=[-1, max_x + 1],
            showgrid=False,
            zeroline=False,
            showticklabels=False
        ),
        yaxis=dict(
            range=[-1, max_y + 1],
            showgrid=False,
            zeroline=False,
            showticklabels=False,
            scaleanchor="x",
            scaleratio=1
        )
    )

    return fig