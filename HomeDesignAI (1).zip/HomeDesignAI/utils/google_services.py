import os
from googleapiclient.discovery import build
from config.api_config import get_google_api_key

class GoogleServicesManager:
    def __init__(self):
        self.api_key = get_google_api_key()
        if not self.api_key:
            raise ValueError("Google API key not found in environment variables")

        # Custom Search Engine ID should be configured properly
        self.search_engine_id = os.environ.get('GOOGLE_SEARCH_ENGINE_ID', '017576662512468239146:omuauf_lfve')

    def get_design_inspiration(self, style: str, room_type: str) -> dict:
        """
        Use Google Custom Search API to find design inspiration images
        based on architectural style and room type
        """
        try:
            service = build('customsearch', 'v1', developerKey=self.api_key)
            query = f"{style} {room_type} interior design"

            result = service.cse().list(
                q=query,
                cx=self.search_engine_id,
                searchType='image',
                num=1
            ).execute()

            if 'items' in result and result['items']:
                return {
                    'image_url': result['items'][0]['link'],
                    'title': result['items'][0]['title']
                }
            return {'image_url': None, 'title': 'No inspiration found'}

        except Exception as e:
            print(f"Error fetching design inspiration: {str(e)}")
            return {'image_url': None, 'title': f'Error: {str(e)}'}