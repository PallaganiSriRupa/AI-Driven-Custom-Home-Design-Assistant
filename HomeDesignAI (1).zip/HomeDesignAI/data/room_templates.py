# Room templates and features for the home design generator

ROOM_TEMPLATES = {
    'Modern': {
        'bedroom': {
            'min_size': 150,
            'max_size': 250,
            'features': ['large windows', 'minimal decoration']
        },
        'bathroom': {
            'min_size': 50,
            'max_size': 100,
            'features': ['clean lines', 'glass shower']
        },
        'kitchen': {
            'min_size': 150,
            'max_size': 300,
            'features': ['island counter', 'open concept']
        }
    },
    'Traditional': {
        'bedroom': {
            'min_size': 150,
            'max_size': 250,
            'features': ['classic molding', 'neutral colors']
        },
        'bathroom': {
            'min_size': 50,
            'max_size': 100,
            'features': ['tub/shower combo', 'classic fixtures']
        },
        'kitchen': {
            'min_size': 150,
            'max_size': 300,
            'features': ['cabinet storage', 'breakfast nook']
        }
    }
}

STYLE_FEATURES = {
    'Modern': {
        'wall_thickness': 0.5,
        'window_size': 'large',
        'ceiling_height': 10,
        'color_palette': ['#FFFFFF', '#000000', '#808080']
    },
    'Traditional': {
        'wall_thickness': 0.75,
        'window_size': 'medium',
        'ceiling_height': 9,
        'color_palette': ['#F5F5DC', '#8B4513', '#DEB887']
    },
    'Contemporary': {
        'wall_thickness': 0.5,
        'window_size': 'extra-large',
        'ceiling_height': 12,
        'color_palette': ['#FFFFFF', '#808080', '#000000']
    },
    'Mediterranean': {
        'wall_thickness': 1.0,
        'window_size': 'medium',
        'ceiling_height': 10,
        'color_palette': ['#F4D03F', '#E59866', '#CD6155']
    }
}
