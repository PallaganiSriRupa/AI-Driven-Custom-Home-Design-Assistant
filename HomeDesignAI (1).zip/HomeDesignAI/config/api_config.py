import os
from typing import Optional

def get_google_api_key() -> Optional[str]:
    """Safely retrieve Google API key from environment variables"""
    return os.environ.get('GOOGLE_API_KEY')

def validate_api_keys() -> bool:
    """Validate that all required API keys are present"""
    required_keys = ['GOOGLE_API_KEY']
    return all(os.environ.get(key) for key in required_keys)
