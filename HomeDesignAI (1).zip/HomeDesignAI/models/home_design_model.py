import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler

class HomeDesignGenerator:
    def __init__(self):
        self.scaler = StandardScaler()
        self.room_sizes = {
            'bedroom': (150, 250),
            'bathroom': (50, 100),
            'kitchen': (150, 300),
            'living_room': (200, 400),
            'dining_room': (150, 250),
            'office': (100, 200)
        }

    def _create_feature_vector(self, num_rooms, house_size, style, requirements):
        """Create a feature vector from input parameters"""
        features = []
        features.extend([num_rooms, house_size, len(requirements)])

        # Style encoding
        style_map = {
            'Modern': [1, 0, 0, 0],
            'Traditional': [0, 1, 0, 0],
            'Contemporary': [0, 0, 1, 0],
            'Mediterranean': [0, 0, 0, 1]
        }
        features.extend(style_map[style])

        # Requirements encoding
        req_features = [
            1 if req in requirements else 0
            for req in ['Open Floor Plan', 'Home Office', 'Large Kitchen', 'Master Suite']
        ]
        features.extend(req_features)

        return np.array(features).reshape(1, -1)

    def _calculate_room_dimensions(self, size):
        """Calculate optimal room dimensions based on size"""
        aspect_ratio = np.random.uniform(0.6, 1.67)  # Common room proportions
        width = np.sqrt(size / aspect_ratio)
        height = size / width
        return width, height

    def _arrange_rooms(self, rooms_df, house_size):
        """Arrange rooms in a grid-like layout"""
        total_width = np.sqrt(house_size) * 1.2  # Add some margin
        current_x, current_y = 0, 0
        max_height_in_row = 0
        arranged_rooms = []

        # Sort rooms by size (larger rooms first)
        rooms_df = rooms_df.sort_values('size', ascending=False)

        for _, room in rooms_df.iterrows():
            width, height = self._calculate_room_dimensions(room['size'])

            # Check if we need to move to next row
            if current_x + width > total_width:
                current_x = 0
                current_y += max_height_in_row
                max_height_in_row = 0

            arranged_rooms.append({
                'room_type': room['room_type'],
                'size': room['size'],
                'x': current_x,
                'y': current_y,
                'width': width,
                'height': height
            })

            current_x += width
            max_height_in_row = max(max_height_in_row, height)

        return pd.DataFrame(arranged_rooms)

    def _allocate_rooms(self, house_size, num_rooms, num_bedrooms, requirements):
        """Allocate room sizes based on requirements"""
        rooms = []
        remaining_size = house_size

        # Add required bedrooms first
        master_suite = 'Master Suite' in requirements
        if master_suite:
            rooms.append(('bedroom', 250))  # Master bedroom
            remaining_size -= 250
            num_bedrooms -= 1

        # Add remaining bedrooms
        for _ in range(num_bedrooms):
            size = np.random.randint(150, 200)
            if remaining_size >= size:
                rooms.append(('bedroom', size))
                remaining_size -= size

        # Required rooms based on special requirements
        required_rooms = {
            'Large Kitchen': ('kitchen', 300),
            'Home Office': ('office', 150)
        }

        # Add required rooms
        for req, (room_type, size) in required_rooms.items():
            if req in requirements and remaining_size >= size:
                rooms.append((room_type, size))
                remaining_size -= size
                num_rooms -= 1

        # Essential rooms (living room and bathrooms)
        essential_rooms = [('living_room', 250)]
        for room_type, size in essential_rooms:
            if remaining_size >= size:
                rooms.append((room_type, size))
                remaining_size -= size
                num_rooms -= 1

        # Allocate remaining rooms
        room_types = ['bathroom', 'dining_room', 'office']
        while num_rooms > 0 and remaining_size > 100:  # Minimum room size threshold
            room_type = np.random.choice(room_types)
            min_size, max_size = self.room_sizes[room_type]
            size = min(np.random.randint(min_size, max_size), remaining_size)

            rooms.append((room_type, size))
            remaining_size -= size
            num_rooms -= 1

        return pd.DataFrame(rooms, columns=['room_type', 'size'])

    def generate_layout(self, num_rooms, num_bedrooms, house_size, style, requirements):
        """Generate a complete house layout"""
        try:
            # Create feature vector
            features = self._create_feature_vector(num_rooms, house_size, style, requirements)

            # Scale features
            scaled_features = self.scaler.fit_transform(features)

            # Generate room allocation
            layout = self._allocate_rooms(house_size, num_rooms, num_bedrooms, requirements)

            # Arrange rooms with proper dimensions
            final_layout = self._arrange_rooms(layout, house_size)

            return final_layout

        except Exception as e:
            print(f"Error generating layout: {str(e)}")
            raise